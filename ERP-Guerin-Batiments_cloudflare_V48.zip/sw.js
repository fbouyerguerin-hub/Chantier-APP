// Service worker — ERP Guérin Bâtiments (Cloudflare Pages)
const CACHE_NAME = 'chantier-app-V48'; // ⚠️ à aligner sur APP_VERSION de chantier-app.html à chaque version
const APP = '/chantier-app'; // Cloudflare Pages sert les pages sans « .html »
const ASSETS = [APP, '/manifest.json', '/logo-guerin.jpg', '/plan-atelier.png', '/icon-192.png'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache =>
      Promise.all(ASSETS.map(url =>
        fetch(url + '?v=' + CACHE_NAME, { cache: 'reload' })
          .then(response => { if (response.ok) return cache.put(url, response); })
          .catch(() => {})
      ))
    )
  );
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  // Données et services externes (Worker Cloudflare, Baserow, EBP, CDN) : jamais
  // interceptés ni mis en cache — l'appli affiche toujours les données à jour.
  if (url.origin !== self.location.origin) return;
  if (e.request.method !== 'GET') return;

  // Ouverture / rechargement de l'appli : réseau d'abord, cache en secours hors-ligne
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request, { cache: 'no-store' })
        .then(response => {
          if (response.ok && url.pathname.replace(/\.html$/, '') === APP) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(APP, clone));
          }
          return response;
        })
        .catch(() => caches.match(APP))
    );
    return;
  }
  // Fichiers de l'appli (logo, plan, icônes, manifeste) : cache d'abord, réseau en secours
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then(cached => cached || fetch(e.request).then(response => {
      if (response && response.ok) {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
      }
      return response;
    }))
  );
});
